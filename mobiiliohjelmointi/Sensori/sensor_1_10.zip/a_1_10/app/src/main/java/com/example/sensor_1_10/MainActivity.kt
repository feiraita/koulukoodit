package com.example.sensor_1_10

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.sensor_1_10.ui.theme.Sensor_1_10Theme

class MainActivity : ComponentActivity(), SensorEventListener, SensorListener {

    private lateinit var sensorManager: SensorManager
    private var accelerometer : Sensor ? = null

    val xArvo = mutableStateOf("")
    val yArvo = mutableStateOf("")
    val zArvo = mutableStateOf("")


    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Sensor_1_10Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Column( modifier = Modifier.padding(innerPadding))

                    {
                        Greeting("Android")
                        Text(text = xArvo.value)
                        Text(text = yArvo.value)
                        Text(text = zArvo.value)

                    }

                }

            }


        }
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)


    }

    override fun onResume() {
        super.onResume()
        accelerometer?.also { acc ->
            sensorManager.registerListener(this, acc, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    override fun onPause() {
        super.onPause()
        if (accelerometer != null) {
            sensorManager.unregisterListener(this,accelerometer)

        }

    }



    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor?.type == Sensor.TYPE_ACCELEROMETER){
            val x = event.values[0]
            val y = event.values[1]
            val z = event.values[0]

            //update uudet sensoriarvot

            xArvo.value = "X: $x"
            yArvo.value = "Y: $y"
            zArvo.value = "Z: $z"

        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        TODO("Not yet implemented")
    }

    override fun onSensorChanged(p0: Int, p1: FloatArray?) {
        TODO("Not yet implemented")
    }

    override fun onAccuracyChanged(p0: Int, p1: Int) {
        TODO("Not yet implemented")
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Sensor_1_10Theme {
        Greeting("Android")
    }
}